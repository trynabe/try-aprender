# Faculty of Information and Communication Technology <br/> ITDS242 Web Technologies Lab <br/> Basic React Lab
## คำชี้แจง
- แบบฝึกปฏิบัตินี้มีทั้งหมด 1 ข้อ ที่เกี่ยวกับการสร้างเว็บแอปพลิเคชันพื้นฐานโดยใช้ React
- การส่งงานขอให้นักศึกษาส่งงานผ่าน Github Classroom ภายในคาบถัดไป

แบบฝึกหัดภาคปฏิบัตินี้ นักศึกษาจะได้พัฒนาฟอร์มโดยใช้ React Framework
### ขั้นตอน
1. นักศึกษาจะต้องเริ่มด้วยการสร้าง React Project โดยใช้คำสั่ง `npx create-react-app reactlab`
2. จากนั้นให้ติดตั้ง packages ที่จำเป็น
3. ไปที่ไฟล์ `index.js`
4. นักศึกษาต้องพัฒนาคลาส `InfoForm` ซึ่งมีฟอร์ม 2 แบบดังนี้ 1. แบบ normal และ 2. แบบ special ที่จะให้ผู้ใช้สามารถใส่ข้อมูลได้ โดยฟอร์มทั้ง 2 ประเภทนั้นจะเป็นดังนี้ <br/>
แบบ Normal <br/>
![normal](expected_output/normal.png) <br/>
แบบ Special <br/>
![special](expected_output/special.png)
5. ในการ render ฟอร์ม จะสามารถแยกประเภทได้ผ่านตัวแปร type ใน props ตัวอย่างเช่น
```javascript
ReactDOM.render(<InfoForm type="normal" />, document.getElementById("root"));
```
6. เมื่อผู้ใช้กดปุ่ม Submit โปรแกรมจะทำการ alert ข้อมูลที่ผู้ใช้งานใส่ในฟอร์ม <br/>
แบบ Normal <br/>
![normal](expected_output/alert_normal.png) <br/>
แบบ Special <br/>
![special](expected_output/alert_special.png)

## การส่งงาน
ให้นักศึกษาส่ง React project และอย่าลบไฟล์ `.gitignore`
