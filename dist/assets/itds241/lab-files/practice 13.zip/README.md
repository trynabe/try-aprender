# Faculty of Information and Communication Technology <br/> ITDS242 Web Technologies Lab <br/> Web Service with Nodejs Lab
## คำชี้แจง
- แบบฝึกปฏิบัตินี้มีทั้งหมด 1 ข้อ ที่เกี่ยวกับการสร้างเว็บเซอร์วิส และการทดสอบเว็บเซอร์วิส
- การส่งงานขอให้นักศึกษาส่งงานผ่าน Github Classroom ภายในคาบถัดไป

แบบฝึกหัดภาคปฏิบัตินี้ นักศึกษาจะได้ใช้ MySQL และ Node.js ในการสร้าง RESTful เว็บเซอร์วิส และทดสอบเว็บเซอร์วิสโดยใช้โปแกรม Postman
### ขั้นตอน
1. นักศึกษาจะต้องทำการเปิด MySQL Server และเข้าใช้งานผ่าน MySQLWorkbench
2. สร้างฐานข้อมูลโดยใช้ชื่อว่า `itds242-[Section]` `[Section]` หมายถึง ห้องของนักศึกษา แต่ถ้านักศึกษามีฐานข้อมูลนี้อยู่แล้วก็สามารถใช้ได้เลย
3. สร้างตารางข้อมูลชื่อว่า `personal_info` ในฐานข้อมูล `itds242-[Section]` สำหรับตารางข้อมูล `personal_info` นั้นจะประกอบไปด้วยชื่อฟิลด์ และประเภทข้อมูลของฟิลด์ตามตารางข้างล่าง <br/>
![schema](expected_output/schema.png)
4. จากนั้นให้ใส่ข้อมูลลงในตารางตามตารางข้างล่าง

| StudentID |	Firstname |	Lastname | Birthdate |	Mobilephone |
| --------- |	--------- |	-------- | --------- |	----------- |
| 1 |	Robert |	Dolls |	1985-01-20 |	0919998877 |
| 2 |	Peter |	Jones |	1980-06-10 |	0834455667 |
| 3 |	Lily |	James |	1991-10-20 |	0889988776 |

5. สร้างไฟล์เว็บเซอร์วิส `StudentService.js` ที่สามารถทำ CRUD operations (Insert, Update, Delete, Select, Select all) จากตาราง `personal_info` ได้
6. จากนั้นทำการทดสอบเว็บเซอร์วิสทั้งหมดด้วยโปรแกรม Postman
7. ให้นักศึกษาจัดทำรายงานการทดสอบเว็บเซอร์วิส โดยในรายงานนั้นจะประกอบไปด้วยหัวข้อตาม CRUD operations (Insert, Update, Delete, Select, Select all) พร้อมทั้งรูปภาพการทดสอบ และบันทึกไฟล์เป็น PDF รูปด้านล่างคือตัวอย่างการทดสอบ Insert operation <br/>
![API output](expected_output/api_output.png)

## การส่งงาน
ให้นักศึกษาส่ง Nodejs project ที่มีไฟล์เว็บเซอร์วิสชื่อว่า `StudentService.js` ด้วย และไฟล์รายงาน `webservic-testing.pdf` และอย่าลบไฟล์ `.gitignore`
