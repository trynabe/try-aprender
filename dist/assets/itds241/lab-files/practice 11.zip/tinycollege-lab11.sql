-- Practice data for Professor search. Run in a local MySQL instance.
CREATE DATABASE IF NOT EXISTS `tinycollege_lab11`;
USE `tinycollege_lab11`;

CREATE TABLE IF NOT EXISTS `Professor` (
    EMP_NUM INT PRIMARY KEY,
    EMP_FNAME VARCHAR(45) NOT NULL,
    EMP_LNAME VARCHAR(45) NOT NULL
);

INSERT IGNORE INTO `Professor` (EMP_NUM, EMP_FNAME, EMP_LNAME) VALUES
    (103, 'Practice', 'Professor 103'),
    (104, 'Practice', 'Professor 104'),
    (105, 'Practice', 'Professor 105'),
    (106, 'Practice', 'Professor 106'),
    (110, 'Practice', 'Professor 110'),
    (114, 'Practice', 'Professor 114'),
    (155, 'Practice', 'Professor 155'),
    (160, 'Practice', 'Professor 160'),
    (162, 'Practice', 'Professor 162'),
    (191, 'Practice', 'Professor 191'),
    (195, 'Practice', 'Professor 195'),
    (209, 'Practice', 'Professor 209'),
    (228, 'Practice', 'Professor 228'),
    (297, 'Practice', 'Professor 297'),
    (299, 'Practice', 'Professor 299'),
    (301, 'Practice', 'Professor 301'),
    (335, 'Practice', 'Professor 335'),
    (342, 'Practice', 'Professor 342'),
    (387, 'Practice', 'Professor 387'),
    (401, 'Practice', 'Professor 401'),
    (425, 'Practice', 'Professor 425'),
    (435, 'Practice', 'Professor 435');
